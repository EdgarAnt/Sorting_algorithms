#include "Nodo.h"

Nodo::Nodo()
{
    sig=nullptr;
    ant=nullptr;
    //ctor
}

Nodo::~Nodo()
{
    //dtor
}
