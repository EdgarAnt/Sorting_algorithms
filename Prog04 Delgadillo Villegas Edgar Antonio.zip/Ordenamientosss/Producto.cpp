#include "Producto.h"

Producto::Producto()
{
    Productos="";
    precio=0;
    id=0;
    //ctor
}

Producto::~Producto()
{
    //dtor
}
